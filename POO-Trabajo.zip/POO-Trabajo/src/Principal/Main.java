
package Principal;


import Controlador.AccionesPrincipal;
import Controlador.ManejadorTabla;
import Modelo.ListaEpleado;
import Modelo.ListaHoraExtra;
import Modelo.ListaHorario;
import Modelo.ListaLabores;
import Modelo.ListaPermiso;
import poo.trabajo.FrmPrincipal;
import poo.trabajo.HorarioEmpleado;
import poo.trabajo.HorasExtras;
import poo.trabajo.LaboresEmpleado;
import poo.trabajo.PermisoEmpleado;
import poo.trabajo.RegistroEmpleado;


public class Main {
    public static ListaEpleado lista;
    public static ManejadorTabla manta;
    public static RegistroEmpleado r1;
    
    public static ListaHorario listah;
    public static ManejadorTabla mantah;
    public static HorarioEmpleado h1;
    
    public static ListaLabores listal;
    public static ManejadorTabla mantal;
    public static LaboresEmpleado l1;
    
    public static ListaHoraExtra listahe;
    public static ManejadorTabla mantahe;
    public static HorasExtras he;
    
    public static PermisoEmpleado me1;
    
    public static FrmPrincipal fp;
    
    public static ListaPermiso listaP;
    public static ManejadorTabla mantaP;
    public static PermisoEmpleado pr;
    
    public static void main(String[] args) {
        
        fp=new FrmPrincipal();
        fp.setVisible(true);
        fp.setLocationRelativeTo(null);
        fp.setLocationRelativeTo(null);
        AccionesPrincipal p=new AccionesPrincipal(fp);
    }
}
