
package Modelo;

import java.util.ArrayList;

public class ListaPermiso {
    ArrayList<Permiso> listaP;
    public ListaPermiso(){
        listaP=new ArrayList();
    }
    public void AgregarLlamada(Permiso P){
        listaP.add(P);
    }
    public Permiso ObtenerPermiso(int pos){
        return listaP.get(pos);
    }
    public int CantidadRegistros(){
        return listaP.size();
    }
}
