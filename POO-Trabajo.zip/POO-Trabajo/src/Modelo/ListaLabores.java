
package Modelo;

import java.util.ArrayList;

public class ListaLabores {
     ArrayList<Labores> listal;
    public ListaLabores(){
        listal=new ArrayList();
    }
    public void AgregarLabores(Labores L){
        listal.add(L);
    }
    public Labores ObtenerLabores(int pos){
        return listal.get(pos);
    }
    public int CantidadRegistros(){
        return listal.size();
    }
}
