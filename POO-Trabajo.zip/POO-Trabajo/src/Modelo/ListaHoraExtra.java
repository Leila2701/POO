
package Modelo;

import java.util.ArrayList;

public class ListaHoraExtra {
     ArrayList<HoraExtra> listahe;
    public ListaHoraExtra(){
        listahe=new ArrayList();
    }
    public void AgregarHorario(HoraExtra HE){
        listahe.add(HE);
    }
    public HoraExtra ObtenerHoraExtra(int pos){
        return listahe.get(pos);
    }
    public int CantidadRegistros(){
        return listahe.size();
    }
}
