
package Modelo;

import java.util.ArrayList;

public class ListaEpleado {
    ArrayList<Empleado> lista;
    public ListaEpleado(){
        lista=new ArrayList();
    }
    public void AgregarLlamada(Empleado E){
        lista.add(E);
    }
    public Empleado ObtenerEmpleado(int pos){
        return lista.get(pos);
    }
    public int CantidadRegistros(){
        return lista.size();
    }
}
