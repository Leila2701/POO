
package Modelo;

public class Login {
    String usuario;
    String cotraseña;
}
