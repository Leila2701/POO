
package Modelo;

public class HoraExtra {
    String codigoExtras;
    int HorasExtras;
    public HoraExtra(){}
    public HoraExtra(String codE,int h){
        this.codigoExtras=codE;
        this.HorasExtras=h;
    }
    public Object[] Registro(int num){
    Object[] fila={num,codigoExtras,HorasExtras};
    return fila;
    } 
}
