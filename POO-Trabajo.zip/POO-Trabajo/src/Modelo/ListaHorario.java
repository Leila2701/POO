
package Modelo;

import java.util.ArrayList;

public class ListaHorario {
     ArrayList<Horario> listah;
    public ListaHorario(){
        listah=new ArrayList();
    }
    public void AgregarHorario(Horario H){
        listah.add(H);
    }
    public Horario ObtenerHorario(int pos){
        return listah.get(pos);
    }
    public int CantidadRegistros(){
        return listah.size();
    }
}
