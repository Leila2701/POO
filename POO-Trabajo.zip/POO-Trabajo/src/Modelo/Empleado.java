
package Modelo;

public class Empleado {
    String apellido;
    String nombre;
    String fechanacimiento;
    String dni;
    String direccion;
    String telefono;
    public Empleado(){ }
    public Empleado(String a,String n,String f,String dni,String d,String t){
        this.apellido=a;
        this.nombre=n;
        this.fechanacimiento=f;
        this.dni=dni;
        this.direccion=d;
        this.telefono=t;
    }
    public Object[] Registro(int num){
    Object[] fila={num,apellido,nombre,fechanacimiento,dni,direccion,telefono};
    return fila;
    }   
}
