
package Modelo;

public class Labores {
    String codigolab;
    String actividad;
    public Labores(){}
    public Labores(String cod,String a){
        this.codigolab=cod;
        this.actividad=a;
    }
    public Object[] Registro(int num){
    Object[] fila={num,codigolab,actividad};
    return fila;
    }
}
