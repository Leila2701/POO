
package Controlador;

public interface Encabezado {
    String[] Encab1={"Num","Apellidos","Nombres","Fecha de Nacimiento","DNI","Direccion","Telefono"}; 
    String[] EncabH={"Num","DNI","Hora de Ingreso","Hora de Salida","Hora de Refrigerio","Fin de Refrigerio"};
    String[] EncabL={"Num","DNI","Actividad que Realiza en la empresa"};
    String[] EncabHE={"Num","DNI","Horas Extras"};
    String[] EncabPE={"Num","DNI","Fecha Permiso","Tiempo","Descripción"};
}
