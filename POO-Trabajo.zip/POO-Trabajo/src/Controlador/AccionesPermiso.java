
package Controlador;

import Modelo.Permiso;
import Principal.Main;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import poo.trabajo.PermisoEmpleado;

public class AccionesPermiso implements ActionListener{
    private PermisoEmpleado pr;
    public AccionesPermiso(PermisoEmpleado pr){
        this.pr=pr;
        this.pr.jbtnRegistrar.addActionListener(this);
        this.pr.jbtnNuevo.addActionListener(this);
    }
    public void actionPerformed(ActionEvent e){
        if(pr.jbtnRegistrar==e.getSource()){
            String dni=pr.jtxtdni.getText();
            SimpleDateFormat formatoFecha=new SimpleDateFormat("dd/MM/yyyy");
            String f=formatoFecha.format(pr.jcadPermiso.getDate());
            String t=pr.jtxtTiempo.getText();
            String d=pr.jtxtDescripcion.getText();
            
            Permiso P=new Permiso(dni,f,t,d);
            Main.listaP.AgregarLlamada(P);
            Main.mantaP.ActualizarP(Main.pr.jtblDatosPermiso,Main.listaP);
        }
        else if(pr.jbtnNuevo==e.getSource()){
            pr.jtxtdni.setText("");
            pr.jtxtTiempo.setText("");
            pr.jtxtDescripcion.setText("");
        }
    }
}
