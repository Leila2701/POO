
package Controlador;

import Modelo.ListaEpleado;
import Modelo.ListaHoraExtra;
import Modelo.ListaHorario;
import Modelo.ListaLabores;
import Modelo.ListaPermiso;
import static Principal.Main.h1;
import static Principal.Main.he;
import static Principal.Main.l1;
import static Principal.Main.pr;
import static Principal.Main.lista;
import static Principal.Main.listah;
import static Principal.Main.listahe;
import static Principal.Main.listal;
import static Principal.Main.listaP;
import static Principal.Main.manta;
import static Principal.Main.mantaP;
import static Principal.Main.mantah;
import static Principal.Main.mantahe;
import static Principal.Main.mantal;
import static Principal.Main.r1;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import poo.trabajo.FrmPrincipal;
import poo.trabajo.HorarioEmpleado;
import poo.trabajo.HorasExtras;
import poo.trabajo.LaboresEmpleado;
import poo.trabajo.MarcarAsistencia;
import poo.trabajo.PermisoEmpleado;
import poo.trabajo.RegistroEmpleado;

public class AccionesPrincipal implements ActionListener{
    private FrmPrincipal fp;
    public AccionesPrincipal(FrmPrincipal fp){
        this.fp=fp;
        fp.jmnRegistroempleado.addActionListener(this);
        fp.jmnRegistroCargo.addActionListener(this);
        fp.jmnHorasextra.addActionListener(this);
        fp.jmnProgramarHorario.addActionListener(this);
        fp.jmnPermisoempleado.addActionListener(this);
        fp.jmnMarcarAsistencia.addActionListener(this);  
        fp.jmSalir.addActionListener(this);
    }
    public void actionPerformed(ActionEvent e){
        if(fp.jmnRegistroempleado== e.getSource()){
            r1 = new RegistroEmpleado();
            r1.setVisible(true);
            r1.setLocationRelativeTo(null);
            lista = new ListaEpleado();
            manta.Actualizar(r1.jtblDatos,lista); 
            Acciones grabar=new Acciones(r1);
        }
        else if(fp.jmnProgramarHorario==e.getSource()){
            h1=new HorarioEmpleado();
            h1.setVisible(true);
            h1.setLocationRelativeTo(null);
            listah=new ListaHorario();
            mantah.ActualizarH(h1.jtblDatosHorario,listah);
            AccionesH grabarh=new AccionesH(h1);
        }
        else if(fp.jmnRegistroCargo==e.getSource()){
            l1=new LaboresEmpleado();
            l1.setVisible(true);
            l1.setLocationRelativeTo(null);
            listal=new ListaLabores();
            mantal.ActualizarL(l1.jtblDatosActividad,listal);
            AccionesL grabarl=new AccionesL(l1);
        }
        else if(fp.jmnMarcarAsistencia==e.getSource()){
            //eliminar 
            MarcarAsistencia ventana4= new MarcarAsistencia();
            ventana4.setLocationRelativeTo(null);
            ventana4.setVisible(true);
            
        }
        else if(fp.jmnPermisoempleado==e.getSource()){
            pr=new PermisoEmpleado();
            pr.setVisible(true);
            pr.setLocationRelativeTo(null);
            listaP=new ListaPermiso();
            mantaP.ActualizarP(pr.jtblDatosPermiso,listaP);
            AccionesPermiso grabarl=new AccionesPermiso(pr);
        }
        else if(fp.jmnHorasextra==e.getSource()){
            he=new HorasExtras();
            he.setVisible(true);
            he.setLocationRelativeTo(null);
            listahe=new ListaHoraExtra();
            mantahe.ActualizarHE(he.jtblDatosHorasExtras,listahe);
            Acciones_Horas_extras grabarhe=new Acciones_Horas_extras(he);
        }
        else if(fp.jmSalir==e.getSource()){
            System.exit(0);
        }
    }
}
