
package Controlador;

import Modelo.Empleado;
import Principal.Main;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import poo.trabajo.RegistroEmpleado;

public class Acciones implements ActionListener{
    private RegistroEmpleado r1;
    public Acciones(RegistroEmpleado r1){
        this.r1=r1;
        this.r1.jbtnRegistrar.addActionListener(this);
        this.r1.jbtnNuevo.addActionListener(this);
    }
    public void actionPerformed(ActionEvent e){
        if(r1.jbtnRegistrar== e.getSource()){
            String a=r1.jtxtApellido.getText();
            String n=r1.jtxtNombre.getText();
            SimpleDateFormat formatoFecha=new SimpleDateFormat("dd/MM/yyyy");
            String f=formatoFecha.format(r1.jdFecha.getDate());
            String dni=r1.jtxtDNI.getText();
            String d=r1.jtxtDireccion.getText();
            String t=r1.jtxtTelefono.getText();
            
            Empleado E=new Empleado(a,n,f,dni,d,t);
            Main.lista.AgregarLlamada(E);
            Main.mantah.Actualizar(Main.r1.jtblDatos, Main.lista);
        }
        else if(r1.jbtnNuevo==e.getSource()){
            r1.jtxtApellido.setText("");
            r1.jtxtNombre.setText("");
            //r1.jtxtFecha.setText("");
            r1.jtxtDNI.setText("");
            r1.jtxtDireccion.setText("");
            r1.jtxtTelefono.setText("");
            r1.jtxtApellido.requestFocus();
        }
        
    }
}
