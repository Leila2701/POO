
package Controlador;

import Modelo.HoraExtra;
import Principal.Main;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import poo.trabajo.HorasExtras;

public class Acciones_Horas_extras implements ActionListener {
    private HorasExtras he;
    public Acciones_Horas_extras(HorasExtras he){
        this.he=he;
        this.he.jbtnRegistrar.addActionListener(this);
    }
    public void actionPerformed(ActionEvent e){
        if(he.jbtnRegistrar==e.getSource()){
            String codE=he.jtxtCodigoHoras.getText();
            int h=Integer.parseInt(he.jtxtHoras.getText());
            
            HoraExtra hex=new HoraExtra(codE,h);
            Main.listahe.AgregarHorario(hex);
            Main.mantahe.ActualizarHE(Main.he.jtblDatosHorasExtras, Main.listahe);

        }
    }
    
}
