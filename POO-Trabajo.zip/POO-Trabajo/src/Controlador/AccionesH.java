package Controlador;

import Modelo.Horario;
import Principal.Main;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import poo.trabajo.HorarioEmpleado;

public class AccionesH implements ActionListener{
    private HorarioEmpleado h1;
    public AccionesH(HorarioEmpleado h1){
        this.h1=h1;
        this.h1.jbtnRegistrarHorario.addActionListener(this);
        this.h1.jbtnNuevoHorario.addActionListener(this);
    }
    public void actionPerformed(ActionEvent e){
        if(h1.jbtnRegistrarHorario==e.getSource()){
            String c=h1.jtxtCodigo.getText();
            String hi=h1.jtxtIngreso.getText();
            String hs=h1.jtxtSalida.getText();
            String hr=h1.jtxtInicioRefrigerio.getText();
            String fr=h1.jtxtFinRefrigerio.getText();
            
            Horario H=new Horario(c,hi,hs,hr,fr);
            Main.listah.AgregarHorario(H);
            Main.manta.ActualizarH(Main.h1.jtblDatosHorario, Main.listah);
        }
        else if(h1.jbtnNuevoHorario==e.getSource()){
            h1.jtxtCodigo.setText("");
            h1.jtxtIngreso.setText("");
            h1.jtxtSalida.setText("");
            h1.jtxtInicioRefrigerio.setText("");
            h1.jtxtFinRefrigerio.setText("");
            h1.jtxtCodigo.requestFocus();
        }
    }
}
