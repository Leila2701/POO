
package Controlador;

import Modelo.Labores;
import Principal.Main;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import poo.trabajo.LaboresEmpleado;

public class AccionesL implements ActionListener{
    private LaboresEmpleado l1;
    public AccionesL(LaboresEmpleado l1){
        this.l1=l1;
        this.l1.jbtnGuardar.addActionListener(this);
        this.l1.jbtnNuevo.addActionListener(this);
    }
    public void actionPerformed(ActionEvent e){
        if(l1.jbtnGuardar==e.getSource()){
            String cod=l1.jtxtCodigoLabores.getText();
            String a=l1.jcbxActividad.getSelectedItem().toString();
            
            Labores L=new Labores(cod,a);
            Main.listal.AgregarLabores(L);
            Main.mantal.ActualizarL(Main.l1.jtblDatosActividad, Main.listal);
        }
        else if(l1.jbtnNuevo==e.getSource()){
            l1.jtxtCodigoLabores.setText("");
            l1.jcbxActividad.setSelectedIndex(0);
            l1.jtxtCodigoLabores.requestFocus();
        }
    }
}
