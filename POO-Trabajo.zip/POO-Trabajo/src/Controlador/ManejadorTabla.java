
package Controlador;

import static Controlador.Encabezado.Encab1;
import Modelo.ListaEpleado;
import Modelo.ListaHoraExtra;
import Modelo.ListaHorario;
import Modelo.ListaLabores;
import Modelo.ListaPermiso;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class ManejadorTabla implements Encabezado{
    public static void Actualizar(JTable tabla,ListaEpleado Lista){
        DefaultTableModel mt=new DefaultTableModel(null,Encab1);   
        tabla.setModel(mt);
        for(int i=0;i<Lista.CantidadRegistros();i++){
        mt.addRow(Lista.ObtenerEmpleado(i).Registro(i+1));
        }   
    }

    public static void ActualizarH(JTable tablaH,ListaHorario ListaH){
        DefaultTableModel mhx=new DefaultTableModel(null,EncabH);
        tablaH.setModel(mhx);
        for(int i=0;i<ListaH.CantidadRegistros();i++){
        mhx.addRow(ListaH.ObtenerHorario(i).Registro(i+1));
    }  
    }
    
    public static void ActualizarL(JTable tablaL,ListaLabores ListaL){
        DefaultTableModel ml=new DefaultTableModel(null,EncabL);
        tablaL.setModel(ml);
        for(int i=0;i<ListaL.CantidadRegistros();i++){
            ml.addRow(ListaL.ObtenerLabores(i).Registro(i+1));
        }
    }
    
    public static void ActualizarHE(JTable tablaHE,ListaHoraExtra ListaHE){
        DefaultTableModel mhe=new DefaultTableModel(null,EncabHE);
        tablaHE.setModel(mhe);
        for(int i=0;i<ListaHE.CantidadRegistros();i++){
            mhe.addRow(ListaHE.ObtenerHoraExtra(i).Registro(i+1));
        }
    }
    
    public static void ActualizarP(JTable tablaPE,ListaPermiso ListaPE){
        DefaultTableModel pe=new DefaultTableModel(null,EncabPE);
        tablaPE.setModel(pe);
        for(int i=0;i<ListaPE.CantidadRegistros();i++){
            pe.addRow(ListaPE.ObtenerPermiso(i).Registro(i+1));
        }
    }
    
    
}
